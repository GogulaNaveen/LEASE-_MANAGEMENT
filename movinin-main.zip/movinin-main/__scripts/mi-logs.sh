#!/usr/bin/env bash

tail -f /opt/movinin/backend/logs/all.log
