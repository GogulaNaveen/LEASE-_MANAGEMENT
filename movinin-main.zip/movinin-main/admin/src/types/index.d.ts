interface ImageItem {
    filename: string
    temp?: boolean
}
