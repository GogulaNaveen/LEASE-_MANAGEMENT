const routes = {
  getCountryCode: '/api/country-code',
}

export default routes
